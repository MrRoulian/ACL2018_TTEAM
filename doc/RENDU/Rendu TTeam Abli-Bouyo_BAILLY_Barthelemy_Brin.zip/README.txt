Pour lancer le jeu il suffit de faire 
java -jar ACL2018_TTeam.jar

Les fichiers autour contiennent les fichiers n�cessaires au bon fonctionnement du jar.
La pr�sentation est disponible dans le zip. 
(Les commandes : pour se d�placer ZQSD et pour frapper les monstres : <espace>)